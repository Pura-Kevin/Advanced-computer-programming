def smallest_missing_positive(nums):
 
    num_set = set(nums)
    smallest = 1

    while True:
        if smallest not in num_set:
            return smallest
        smallest += 1


# Example usage
arr = [3, 4, -1, 1,0]
print("Smallest missing positive:", smallest_missing_positive(arr))