import random  # Import the random module to let the computer make random choices

def play():
    # Print welcome message and instructions
    print("Welcome to Rock, Paper, Scissors!")
    print("Choices: rock, paper, scissors")

    # Start an infinite loop so the game keeps running until the player quits
    while True:
        # Ask the player for their move and convert it to lowercase
        user_choice = input("Your move: ").lower()

        # Validate input: only allow rock, paper, or scissors
        if user_choice not in ["rock", "paper", "scissors"]:
            print("Invalid choice. Please choose rock, paper, or scissors.")
            continue  # Skip to the next loop iteration

        # Computer randomly picks rock, paper, or scissors
        computer_choice = random.choice(["rock", "paper", "scissors"])
        print(f"Computer chose: {computer_choice}")

        # Compare choices to determine the outcome
        if user_choice == computer_choice:
            print("It's a tie!")  # Both picked the same
        elif (user_choice == "rock" and computer_choice == "scissors") or \
             (user_choice == "paper" and computer_choice == "rock") or \
             (user_choice == "scissors" and computer_choice == "paper"):
            print("You win!")  # Player wins in these cases
        else:
            print("You lose!")  # Otherwise, computer wins

        # Ask if the player wants to play again
        play_again = input("Play again? (y/n): ").lower()
        if play_again != "y":
            print("Thanks for playing!")  # Exit message
            break  # Break out of the loop to end the game

# Run the game only if this file is executed directly
if __name__ == "__main__":
    play()